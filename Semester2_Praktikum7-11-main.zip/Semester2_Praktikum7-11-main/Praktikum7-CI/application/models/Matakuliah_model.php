<?php
class Matakuliah_model extends CI_Model {
    public $matakuliah;
    public $dosenpengajar;
    public $sks;
    public $kode;
    public $semester;
    public $hari;
    public $ruangan;

}
